# acbomb
This is the power full sms bomber

How to install :-

Step 1:- pkg update -y && pkg upgrade -y

Step 2:- pkg install git -y

Step 3:- pkg install python -y

Step 4:- pkg install python2 -y

Step 5:- pkg install python3 -y

Step 6:- git clone https://github.com/tuntunihaxor/acbomb

Step 7:- cd acbomb && ls

Step 8:- python acbomb.py

Then Give Your Victim Number In The First Box ( Without +88)

Then In The Second Box Insert The Amount To Be Sent..


Then Enjoy 🥰🥰
